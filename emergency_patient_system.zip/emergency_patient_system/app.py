"""
Cloud-Based Emergency Patient Monitoring System
Flask Backend - app.py
Can be deployed on AWS / Render (REST API architecture)
"""

from flask import Flask, jsonify, request, send_from_directory
import random
import os

app = Flask(__name__, static_folder='static', template_folder='templates')

# ─────────────────────────────────────────────
# Simulated Patient Database (in-memory)
# ─────────────────────────────────────────────
PATIENTS = {
    "patient1": {"password": "pass123", "name": "Arjun Kumar",   "age": 45, "id": "P-1001"},
    "patient2": {"password": "pass456", "name": "Priya Sharma",  "age": 32, "id": "P-1002"},
    "admin":    {"password": "admin",   "name": "Test Patient",  "age": 55, "id": "P-1003"},
}

# ─────────────────────────────────────────────
# Static Emergency Data
# ─────────────────────────────────────────────
HOSPITALS = [
    {"name": "Apollo Hospital",      "location": "Greams Road, Chennai",       "distance": "1.2 km", "phone": "+91-44-28293333"},
    {"name": "City Care Hospital",   "location": "Anna Nagar, Chennai",        "distance": "2.8 km", "phone": "+91-44-26161616"},
    {"name": "Government Hospital",  "location": "Park Town, Chennai",         "distance": "3.5 km", "phone": "+91-44-25305000"},
    {"name": "Fortis Malar Hospital","location": "Adyar, Chennai",             "distance": "4.1 km", "phone": "+91-44-42892222"},
]

DOCTORS = [
    {"name": "Dr. Ravi Shankar",  "specialization": "Cardiologist",         "available": True,  "experience": "18 yrs"},
    {"name": "Dr. Meena Iyer",    "specialization": "General Physician",    "available": True,  "experience": "12 yrs"},
    {"name": "Dr. Kumar Raj",     "specialization": "Emergency Specialist", "available": True,  "experience": "20 yrs"},
    {"name": "Dr. Anita Nair",    "specialization": "Pulmonologist",        "available": False, "experience": "15 yrs"},
]

# ─────────────────────────────────────────────
# Serve HTML Pages
# ─────────────────────────────────────────────
@app.route('/')
def index():
    return send_from_directory('templates', 'index.html')

@app.route('/dashboard')
def dashboard():
    return send_from_directory('templates', 'dashboard.html')

@app.route('/emergency')
def emergency():
    return send_from_directory('templates', 'emergency.html')

# ─────────────────────────────────────────────
# API 1: /login  — Authenticate patient
# ─────────────────────────────────────────────
@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()

    # Check credentials
    if username in PATIENTS and PATIENTS[username]['password'] == password:
        patient = PATIENTS[username]

        # Simulate a quick health check on login
        heart_rate   = random.randint(60, 130)
        oxygen_level = random.randint(80, 100)
        temperature  = round(random.uniform(36.0, 40.0), 1)

        # Determine status
        is_critical = heart_rate > 110 or oxygen_level < 90
        status = "critical" if is_critical else "normal"

        return jsonify({
            "success": True,
            "status": status,
            "patient": {
                "name": patient["name"],
                "age":  patient["age"],
                "id":   patient["id"],
            },
            "vitals": {
                "heart_rate":   heart_rate,
                "oxygen_level": oxygen_level,
                "temperature":  temperature,
            }
        })
    else:
        return jsonify({"success": False, "message": "Invalid username or password"}), 401

# ─────────────────────────────────────────────
# API 2: /patient-data — Live simulated vitals
# ─────────────────────────────────────────────
@app.route('/patient-data', methods=['GET'])
def patient_data():
    # Simulate real-time patient vitals with random values
    heart_rate   = random.randint(60, 130)
    oxygen_level = random.randint(80, 100)
    temperature  = round(random.uniform(36.0, 40.0), 1)

    # Condition logic
    hr_condition    = "critical" if heart_rate   > 110 else ("warning" if heart_rate > 100 else "normal")
    oxy_condition   = "critical" if oxygen_level < 90  else ("warning" if oxygen_level < 94 else "normal")
    temp_condition  = "critical" if temperature  > 39  else ("warning" if temperature > 38 else "normal")

    # Overall status: worst of all conditions
    conditions = [hr_condition, oxy_condition, temp_condition]
    if "critical" in conditions:
        overall_status = "critical"
    elif "warning" in conditions:
        overall_status = "warning"
    else:
        overall_status = "normal"

    return jsonify({
        "heart_rate":      heart_rate,
        "oxygen_level":    oxygen_level,
        "temperature":     temperature,
        "hr_condition":    hr_condition,
        "oxy_condition":   oxy_condition,
        "temp_condition":  temp_condition,
        "overall_status":  overall_status,
        "timestamp":       __import__('datetime').datetime.now().strftime("%H:%M:%S")
    })

# ─────────────────────────────────────────────
# API 3: /emergency-data — Hospitals & Doctors
# ─────────────────────────────────────────────
@app.route('/emergency-data', methods=['GET'])
def emergency_data():
    return jsonify({
        "hospitals": HOSPITALS,
        "doctors":   DOCTORS,
        "alert_message": "EMERGENCY! Patient condition is critical. Immediate attention required.",
        "emergency_number": "108"
    })

# ─────────────────────────────────────────────
# API 4: /book-appointment — Book a doctor
# ─────────────────────────────────────────────
@app.route('/book-appointment', methods=['POST'])
def book_appointment():
    data        = request.get_json()
    doctor_name = data.get('doctor', 'Available Doctor')
    hospital    = data.get('hospital', 'Nearest Hospital')
    patient_id  = data.get('patient_id', 'Unknown')

    # Simulate booking (in production, save to DB)
    booking_ref = f"APT-{random.randint(10000, 99999)}"

    return jsonify({
        "success": True,
        "message": f"Appointment booked successfully with {doctor_name} at {hospital}.",
        "booking_ref": booking_ref,
        "patient_id":  patient_id,
        "estimated_wait": f"{random.randint(5, 20)} minutes"
    })

# ─────────────────────────────────────────────
# Run the app
# ─────────────────────────────────────────────
if __name__ == '__main__':
    # Use host='0.0.0.0' for cloud deployment (AWS / Render)
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
