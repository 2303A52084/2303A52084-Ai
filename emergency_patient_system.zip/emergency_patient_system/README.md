# 🏥 MediPulse — Cloud-Based Emergency Patient Monitoring System

A full-stack web application for real-time patient health monitoring with smart emergency assistance.

---

## 📁 Project Structure

```
emergency_patient_system/
├── app.py                  ← Flask backend (all APIs)
├── requirements.txt        ← Python dependencies
├── README.md
└── templates/
    ├── index.html          ← Login page
    ├── dashboard.html      ← Patient vitals dashboard
    └── emergency.html      ← Emergency alert & booking page
```

---

## 🚀 How to Run (VS Code / Local)

### Step 1 — Install Python dependencies
```bash
pip install -r requirements.txt
```

### Step 2 — Start the Flask server
```bash
python app.py
```

### Step 3 — Open in browser
```
http://localhost:5000
```

---

## 🔐 Demo Login Credentials

| Username  | Password | Notes                     |
|-----------|----------|---------------------------|
| patient1  | pass123  | Normal / Critical (random)|
| patient2  | pass456  | Normal / Critical (random)|
| admin     | admin    | Normal / Critical (random)|

> Health status is simulated randomly on each login.

---

## 🌐 API Endpoints

| Method | Endpoint           | Description                          |
|--------|--------------------|--------------------------------------|
| POST   | /login             | Authenticate patient, return status  |
| GET    | /patient-data      | Get live simulated vitals            |
| GET    | /emergency-data    | Get hospitals & doctors list         |
| POST   | /book-appointment  | Book a doctor appointment            |

---

## 🏥 Health Logic

| Vital        | Warning         | Critical         |
|--------------|-----------------|------------------|
| Heart Rate   | > 100 bpm       | > 110 bpm        |
| SpO₂         | < 94%           | < 90%            |
| Temperature  | > 38°C          | > 39°C           |

---

## ☁️ Cloud Deployment

### Deploy to Render.com (Free)
1. Push this folder to a GitHub repository
2. Go to render.com → New Web Service
3. Connect your repo, set:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `python app.py`
4. Done! Your app is live.

### Deploy to AWS EC2
1. Launch an EC2 instance (Amazon Linux / Ubuntu)
2. SSH in and run:
   ```bash
   git clone <your-repo>
   cd emergency_patient_system
   pip install -r requirements.txt
   python app.py
   ```
3. Open port 5000 in Security Group settings.

---

## ✨ Features
- 🔴 Real-time vitals monitoring (auto-refresh every 5s)
- 🚨 Automatic emergency popup on critical readings
- 📊 Live waveform charts per vital
- 🏥 Nearby hospital listing with distances
- 👨‍⚕️ Doctor availability & specializations
- 📅 One-click appointment booking
- ☁️ REST API architecture (cloud-ready)
